# redshift-utils
custom functions for redshift
