from setuptools import setup, find_packages

setup(
    name='redshift_utils',
    version='0.1',
    author='Martin Conur',
    author_email='martincontrerasur@gmail.com',
    scripts=[],
    url='',
    license='MIT',
    description='custom functions for redshift within Sagemaker Studio',
    long_description='',
    long_description_content_type="text/markdown",
    # install_requires=[
    #     "botocore",
    #     "boto3",
    #     "sagemaker"
    # ],
)